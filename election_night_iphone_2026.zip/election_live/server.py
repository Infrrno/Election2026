#!/usr/bin/env python3
"""Election Night Live: standard-library HTTP server and read-only API proxy."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.request import Request, urlopen
from urllib.parse import urlparse, parse_qs, quote
from urllib.error import HTTPError
from pathlib import Path
import json, time, threading, os

BASE=Path(__file__).resolve().parent
SOURCES={
 'core':'https://thepeoplestally.com/data/core.json',
 'results':'https://thepeoplestally.com/data/results.json',
 'openhouse':'https://openamerica.io/elections/results.json?year=2026&office=House',
 'opensenate':'https://openamerica.io/elections/results.json?year=2026&office=Senate',
 'opengovernor':'https://openamerica.io/elections/results.json?year=2026&office=Governor'
}
cache={}; lock=threading.Lock()

def get_remote(url, ttl=60):
 now=time.time()
 with lock:
  record=cache.get(url)
  if record and now-record[0]<ttl:return record[1],False
 try:
  req=Request(url,headers={'User-Agent':'ElectionNightLive/1.0 (public dashboard)', 'Accept':'application/json'})
  with urlopen(req,timeout=16) as r:
   obj=json.loads(r.read(8_000_000).decode('utf-8'))
  with lock: cache[url]=(time.time(),obj)
  return obj,False
 except Exception as e:
  if record:return record[1],True
  raise RuntimeError(str(e))

class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw): super().__init__(*a,directory=str(BASE),**kw)
 def respond(self,obj,status=200):
  raw=json.dumps(obj,ensure_ascii=False).encode()
  self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Access-Control-Allow-Origin','*');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
 def do_GET(self):
  p=urlparse(self.path)
  if p.path=='/api/data':
   src=parse_qs(p.query).get('source',[''])[0]
   if src not in SOURCES:return self.respond({'error':'Unknown source'},400)
   try:
    data,stale=get_remote(SOURCES[src],60 if src!='core' else 300)
    return self.respond({'data':data,'stale_cache':stale,'fetched_at':int(time.time()),'source':SOURCES[src]})
   except Exception as e:return self.respond({'error':str(e),'source':SOURCES[src]},503)
  if p.path=='/api/market':
   q=parse_qs(p.query).get('q',[''])[0].strip()[:110]
   if not q:return self.respond({'error':'Missing query'},400)
   url='https://gamma-api.polymarket.com/public-search?q='+quote(q)+'&limit_per_type=15'
   try:
    data,stale=get_remote(url,35)
    return self.respond({'data':data,'stale_cache':stale,'fetched_at':int(time.time())})
   except Exception as e:return self.respond({'error':str(e)},503)
  if p.path=='/':self.path='/index.html'
  return super().do_GET()

if __name__=='__main__':
 port=int(os.environ.get('PORT','8765'))
 print(f'Election Night Live running at http://localhost:{port}',flush=True)
 ThreadingHTTPServer(('0.0.0.0',port),Handler).serve_forever()
