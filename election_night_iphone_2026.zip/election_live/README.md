# Election Night Live — 2026

A **live** dashboard, not a historical screenshot. Built for the November 3, 2026 U.S. midterms.

## Start

Install Python 3 if needed. In this folder, run:

```bash
python3 server.py
```

Open **http://localhost:8765** in your browser. Keep the terminal open. On Windows, `py server.py` may work instead.

Internet access is required. The Python server fetches publicly available election and prediction-market data; it is read-only and requires no API key or third-party package. The map uses online Leaflet and map tiles.

## Data accuracy

- Source: The People's Tally race roster and results (2026), with an independently labeled Open America official-state-feed fallback. Their coverage may be incomplete. Missing a race from a live feed never means zero votes.
- Source: Polymarket Gamma API public search, when a relevant contract is found. Market prices imply tradable-market probabilities and **are not** vote shares or independent predictions made by this app.
- Clock updates every second; results are polled every 60 seconds and Polymarket every 35 seconds while a race is selected. Upstream feeds may update more slowly.
- No race is labeled "called" unless its results feed explicitly indicates a call, and no party flip is considered confirmed until then.
- The current officeholder is the **pre-election** incumbent from the race roster. "Open seat" means the incumbent is not running, not that the party is changing.
- House geography uses a state map. Click a state to filter House districts. It is **not** a congressional-district boundary map.

Data credit: The People's Tally (CC BY 4.0), Open America, underlying state election offices, and Polymarket.

## Run on iPhone (Safari)

This live app needs a publicly accessible Python server. Opening index.html directly in Files is not enough, because it requests `/api/data` and `/api/market`.

To host it: put these files at the root of a GitHub repository, then deploy that repository as a Render web service using the included `render.yaml` blueprint (or configure a Python web service with `python3 server.py`). Open the Render HTTPS URL in Safari. Use Safari Share > Add to Home Screen for an app-like experience.

The provided Render free plan may sleep during inactivity, so initial loads can be delayed. If you need reliably uninterrupted election-night uptime, select an always-on hosting plan. The live election feeds themselves may lag or have gaps.
